export const routes = [
  { path: '/', title: 'Home' },
  { path: '/products', title: 'Products' },
  { path: '/about', title: 'About' },
  { path: '/contact', title: 'Contact' },
]

export default routes
