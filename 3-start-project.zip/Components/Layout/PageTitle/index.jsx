/** @jsxImportSource @emotion/react */
import React from 'react'
import { css } from '@emotion/react'

const styles = css`
  margin: 0 0 20px 0;
`

export function PageTitle({ title }) {
  return <h2 css={styles}>{title}</h2>
}

export default PageTitle
