/** @jsxImportSource @emotion/react */
import React from 'react'
import TopMenu from 'Components/Layout/TopMenu'
import { css } from '@emotion/react'

const styles = css`
  margin: 20px;
  padding: 20px;
  background-color: #f9f9f9;
  border-radius: 10px;
`

export default function Layout({ children }) {
  return (
    <>
      <TopMenu />
      <main css={styles}>{children}</main>
    </>
  )
}
