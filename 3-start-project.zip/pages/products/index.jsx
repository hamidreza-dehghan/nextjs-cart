/** @jsxImportSource @emotion/react */
import React from 'react'
import PageTitle from 'Components/Layout/PageTitle'
import { css } from '@emotion/react'

import Image from 'next/image'
import Link from 'next/link'
import list from './list'

const styles = css`
  display: inline-block;
  margin: -10px;
  a {
    overflow: hidden;
    border-radius: 10px;
    position: relative;
    float: left;
    margin: 10px;
    img {
      width: 100%;
      float: left;
    }
    label {
      position: absolute;
      z-index: 8;
      left: 0;
      bottom: 50px;
      width: 100%;
      text-align: center;
      color: #333;
    }
  }
`

export function Products() {
  return (
    <>
      <PageTitle title="Products" />
      <div css={styles}>
        {list.map((item) => (
          <Product {...item} key={item.id} />
        ))}
      </div>
    </>
  )
}

export function Product({ id, title, image }) {
  return (
    <Link href={`/products/${id}`}>
      <Image src={image} alt={title} width="330" height="330" />
      <label>{title}</label>
    </Link>
  )
}

export default Products
