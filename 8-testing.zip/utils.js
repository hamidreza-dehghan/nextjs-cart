export function imageLoader(lock) {
  return `https://loremflickr.com/300/300/technics?lock=${lock}`
}
