import React from 'react'
import { ThemeProvider } from '@emotion/react'
import { Provider } from 'react-redux'
import App from 'next/app'

import Layout from 'containers/Layout'
import theme from 'theme'
import { store } from 'store'

function MyApp({ Component, pageProps }) {
  return (
    <Provider store={store}>
      <ThemeProvider theme={theme}>
        <Layout>
          <Component {...pageProps} />
        </Layout>
      </ThemeProvider>
    </Provider>
  )
}

MyApp.getInitialProps = async (appContext) => {
  const pageProps = await App.getInitialProps({
    ...appContext,
    ctx: { ...appContext.ctx, reduxStore: store },
  })
  return {
    ...pageProps,
  }
}

export default MyApp
